﻿const VERSION = {
    build: 106,
    ver: '1.0.2',
    date: '20240304-1310',
    locales: [
        ['ru-ru', 'Русский'],
        ['en-us', 'English (United States)'],
    ],
    prerelease: false,
    server: 'https://igorpc.ru'
}
