var ConfigPC = {
    'CPU': 'Intel(R) Core(TM) CPU i7-2677M @ 1.80GHz',
    'CPUFreq': 1800,
    'RAM': 8192,
    'GPU': 'NVIDIA GeForce GTX 1660',
}