var LOCALE_langpackInfo = [
    'ru-ru',
    '86',
    'Русский',
    'Россия'
]