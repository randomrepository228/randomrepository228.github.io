var LOCALE_control = [
    '',
    'Панель управления',
    {
        'MainPage': [
            'Панель управления',
        ],
        'SystemInfo': [
            'Система',
            'Гб',
            'Мб',
        ],
        'SystemNSecurity': [
            'Система и безопасность',
        ],
        'AppearanceNPersonalize': [
            'Оформление и персонализация'
        ],
        'Personalize': [
            'Персонализация'
        ],
        'WindowColors': [
            'Цвет и внешний вид'
        ],
        'DesktopWallpaper': [
            'Цвет и внешний вид'
        ]
    }
]