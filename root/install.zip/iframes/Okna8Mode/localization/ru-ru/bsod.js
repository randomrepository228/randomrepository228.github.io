var LOCALE_bsod = [
    '',
    `
    <h1 style="font-weight: 300; color: white; font-size: 140px; margin-bottom: 60px;">
        :(
    </h1>
    <h2 style="font-weight: 300; color: white; font-size: 30px;">
        На вашем ПК возникла проблема, и его необходимо перезагрузить.
    </h2>
    <h2 style="font-weight: 300; color: white; font-size: 30px;">
        Мы лишь собираем некоторые сведения об ошибке, а затем будет
    </h2>
    <h2 style="font-weight: 300; color: white; font-size: 30px;">
        автоматически выполнена перезагрузка.
    </h2>
    <h3 style="font-weight: 100; color: white; font-size: 20px; margin-top: 80px;">
        При желании вы можете найти в интернете информацию по этому коду ошибки: ERR_
    </h3>`
]