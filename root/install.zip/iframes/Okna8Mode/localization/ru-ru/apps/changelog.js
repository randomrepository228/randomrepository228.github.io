var LOCALE_changelog = [
    "",
    "Changelog",
    "Changelog",
    "Светлая",
    "Тёмная",
    "Changelog",
    "Последнее обновление"
]