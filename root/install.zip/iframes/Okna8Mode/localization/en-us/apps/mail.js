var LOCALE_mail = [
    "",
    "Mail",
    "Mail",
    "Mail",
    "Feedback"
]