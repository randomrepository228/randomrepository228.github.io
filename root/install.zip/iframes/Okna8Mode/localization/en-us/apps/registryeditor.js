var LOCALE_registryeditor = [
    "",
    "Registry editor",
    "Registry editor",
    "Navigation",
    "Welcome",
    "<h1>Registry editor</h1><p>This app can simple edit localSotrage. Be careful: incorrect edit localStorage can lead to breakage.</p>",
    "Edit",
    "Edit as string",
    "Save"
]