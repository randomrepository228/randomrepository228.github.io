var LOCALE_app_calc = [
    "",
    "Calculator",
    "Calculator",
    "Standart",
    "Engineer",
    "Converter"
]