var LOCALE_changelog = [
    "",
    "Changelog",
    "Changelog",
    "Light",
    "Dark",
    "Changelog",
    "Last update"
]