var MenuBars = {
    'view': `
        <div class="element" onclick="">Обычный</div>
        <div class="element" onclick="">Инженерный</div>
        <div class="element" onclick="">Программист</div>
        <div class="element" onclick="">Статистика</div>
        <div class="separator"></div>
        <div class="element" onclick="">Журнал</div>
        <div class="element" onclick="">Группировка цифр по разрядам</div>
        <div class="separator"></div>
        <div class="element" onclick="">Обычный</div>
        <div class="element" onclick="">Преобразование единиц</div>
        <div class="element" onclick="">Вычисление даты</div>
        <div class="element" onclick="">Листы</div>
    `,
    'edit': `
        <div class="element" onclick="">Копировать</div>
        <div class="element" onclick="">Вставить</div>
        <div class="separator"></div>
        <div class="element" onclick="">Журнал</div>
    `,
    'help': `
        <div class="element" onclick="">Показать справку</div>
        <div class="separator"></div>
        <div class="element" onclick="Exec('winver')">О программе</div>
    `,
}