var LOCALE_music = [
    "",
    "Music",
    "Music",
    "Music",
    "Collection"
]