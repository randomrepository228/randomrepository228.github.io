var LOCALE_calendar = [
    "",
    "Calendar",
    "Calendar",
    "Calendar",
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
]