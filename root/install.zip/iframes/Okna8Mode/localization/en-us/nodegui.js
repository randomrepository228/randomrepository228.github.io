var LOCALE_nodegui = [
    "",
    "Okna8 now in fullscreen",
    "Menu bar and window buttons hidden. To exit fullscreen, press F11 on keyboard. This warning will not shown in the future.",
    "OK",
    "File",
    "View",
    "Help"
]