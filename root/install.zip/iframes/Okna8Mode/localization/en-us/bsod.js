var LOCALE_bsod = [
    '',
    `
    <h1 style="font-weight: 300; color: white; font-size: 140px; margin-bottom: 60px;">
        :(
    </h1>
    <h2 style="font-weight: 300; color: white; font-size: 30px;">
        Your PC ran into a problem and needs to restart. We\`re just
    </h2>
    <h2 style="font-weight: 300; color: white; font-size: 30px;">
        collecting some error info, and then you can restart.
    </h2>
    <h3 style="font-weight: 100; color: white; font-size: 20px; margin-top: 80px;">
        If you\`d like to know more you can search online later for this error:<br>ERR_
    </h3>`
]