var LOCALE_langpackInfo = [
    'en-us',
    '85',
    'English',
    'USA'
]