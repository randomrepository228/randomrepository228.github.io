var LOCALE_firstboot = [
    "",
    "Please wait",
    "Getting ready",
    "Getting devices ready",
    "Rebooting",
    "Preparing",
    "Reseting PC to factory state"
]