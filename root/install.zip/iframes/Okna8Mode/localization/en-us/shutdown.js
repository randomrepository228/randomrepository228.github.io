var LOCALE_shutdown = [
    '',
    'Shutting down',
    'Rebooting',
    'Please wait',
    'Logging off',
    'Locking',
    'Configuring Windows updates<br>000% complete<br>Do not turn off your computer.',
    'Configuring Windows updates<br>Do not turn off your computer.'
]