var LOCALE_clock = [
    "",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
    "January ",
    "February ",
    "Marth ",
    "April ",
    "May ",
    "Juny ",
    "July ",
    "August ",
    "September ",
    "Octember ",
    "November ",
    "December ",
    0, // 0 - June 24, 1 - 24 июня
    '', // Symbol(s) after year
    1, // Display the day of the week before the LongDate
]