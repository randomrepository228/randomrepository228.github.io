var LOCALE_desktop = [
    "",
    "Desktop",
    "Control panel",
    "Personalization",
    "About PC",
    "Help",
    "Language settings",
    "For change keyboard press Windows+SPACE",
    {
        'en-us':['ENG','English (USA)','USA keyboard']
    },
    ['en-us'],
    'Show desktop',
    'Task manager',
    'Properties'
]