var LOCALE_winver = [
    '',
    `<img src="../../../img/logo/winver1.bmp" alt="">
    <div class="GUI_separator" style="width: 425px; margin-top: 7px; margin-left: 16px; margin-bottom: 16px;"></div>
    <p>Майкрософт Windows</p>
    <p>Версия ${VERSION['ver']} (сборка ${VERSION['build']})</p>
    <p>© Корпорация Майкрософт (Microsoft Corporation), 2013. Все права</p>
    <p>Операционная система Windows 8.1 Профессиональная и пользовательский интерфейс в ней защищены правами на товарные знаки и иные объекты интеллектуальной собственности в США и других странах.</p>
    <p></p>`,
    'Windows: сведения',
    'Лицензионное соглашение Майкрософт',
    'ОК'
]