function ConnectScript(path) {
    let script = document.createElement('script')
    script.src = path
    document.head.append(script)
}