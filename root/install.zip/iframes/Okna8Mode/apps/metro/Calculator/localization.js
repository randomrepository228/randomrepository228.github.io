$(document).ready(()=>{
    $('.metroAppHeader_container > div > h6').html(LOCALE_app_calc[1])
    $('#cb_panel_settings_tile_appname').html(LOCALE_app_calc[2])
    $('#link_mode_standart').html(LOCALE_app_calc[3])
    $('#link_mode_engineer').html(LOCALE_app_calc[4])
    $('#link_mode_converter').html(LOCALE_app_calc[5])
});