$(document).ready(()=>{
    $('.leftpanel > .leftpanelContent > h1').html(LOCALE_music['3'])
    $('.main > h1').html(LOCALE_music['4'])
})