// for (a of document.querySelector(".menubar").querySelector(".element")){

// }
if (window.parent){
    addEventListener("mousedown", () => {
        parent.setActive(frameElement.parentElement.parentElement.parentElement)
    })
    addEventListener("touchstart", e => {
        e.preventDefault()
        parent.setActive(frameElement.parentElement.parentElement.parentElement)
    })
}
function minimise(){
    for(a of document.querySelectorAll(".content")){
        a.parentElement.className = a.parentElement.className.replace(" maximisedm", "")
    }
}
function maximise(){
    for(a of document.querySelectorAll(".content")){
        a.parentElement.className += " maximisedm"
    }
}
function focus(){
    for(a of document.querySelectorAll(".content")){
        a.parentElement.className += " focus"
    }
}
function unfocus(){
    for(a of document.querySelectorAll(".content")){
        a.parentElement.className = a.parentElement.className.replace(" focus", "")
    }
}
function tabHandler(elem){
    for (a of elem.firstElementChild.children){
        if (!a.hasAttribute("disabled")){
            a.setAttribute('onmousedown', 
               `for (a of this.parentElement.parentElement.querySelectorAll("article[role=tabpanel]")){
                    a.style.display = "none"
                };
                this.parentElement.parentElement.querySelector("#"+this.getAttribute("aria-controls")).style.display = "block"
                for (a of this.parentElement.parentElement.querySelectorAll(".button\[role=tab]")) {
                    a.setAttribute("aria-selected", "")
                }
                this.parentElement.parentElement.querySelector\(".button\[role=tab][aria-controls="+this.getAttribute("aria-controls")+"]").setAttribute("aria-selected", "true")`)
            a.setAttribute('ontouchstart', 
               `event.preventDefault();
                for (a of this.parentElement.parentElement.querySelectorAll("article[role=tabpanel]")){
                    a.style.display = "none"
                };
                this.parentElement.parentElement.querySelector("#"+this.getAttribute("aria-controls")).style.display = "block"
                for (a of this.parentElement.parentElement.querySelectorAll(".button\[role=tab]")) {
                    a.setAttribute("aria-selected", "")
                }
                this.parentElement.parentElement.querySelector\(".button\[role=tab][aria-controls="+this.getAttribute("aria-controls")+"]").setAttribute("aria-selected", "true")`)
        }
    }
}